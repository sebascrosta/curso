/*
    Objeto literal:

        Al igual que las propiedades los métodos se pueden acceder por corchetes
*/

var perro = {
    ladrar: function() {
        console.log('GUAU');
    }
}

perro['ladrar']();
perro['ladrar']();
perro['ladrar']();
