/*
    Javascript en el Browser:

        1. Abrir una ventana de Chrome
        2. Abrir la barra Developers Tool (CMD + SHIFT + i)
        3. Copiar y pegar el siguiente código en el tab console
*/

// Los browser tienen implementada una versión de console.log al igual que node
console.log('Bienvenidos a Javascript en el Browser');
