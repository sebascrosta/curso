/*
    Screen:
        Por medio del objeto screen podemos obtener valores sobre la pantalla.

        Estructura:
            window.screen

        Propiedades:
            window.screen.height
            window.screen.width
*/

console.log('ancho de la pantalla: ', window.screen.width);
console.log('alto de la pantalla: ', window.screen.height);
